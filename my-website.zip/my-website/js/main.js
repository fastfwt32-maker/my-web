// ===== ملف main.js - الجافاسكريبت للموقع =====

// 1. ننتظر حتى يتم تحميل الصفحة بالكامل
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ تم تحميل الموقع بنجاح!');
    
    // تهيئة جميع المكونات
    initNavigation();
    initContactForm();
    initScrollEffects();
    initDarkMode();
    initSkillsAnimation();
    initMobileMenu();
    
    // عرض رسالة ترحيب
    showWelcomeMessage();
});

// 2. تهيئة شريط التنقل
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // إضافة تأثير عند النقر
            this.style.transform = 'scale(0.95)';
            
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
            
            // تحديث الرابط النشط
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // إذا كان الرابط لنفس الصفحة، ننتقل بسلاسة
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// 3. إدارة نموذج الاتصال
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (!contactForm) return; // إذا لم يكن النموذج موجوداً في الصفحة
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault(); // منع إرسال النموذج العادي
        
        // جمع البيانات من النموذج
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value,
            contactMethod: document.querySelector('input[name="contact-method"]:checked')?.value || 'email'
        };
        
        // التحقق من البيانات
        if (!validateForm(formData)) {
            return;
        }
        
        // عرض رسالة تحميل
        showLoading('جاري إرسال رسالتك...');
        
        // محاكاة إرسال النموذج (في الواقع، هنا تضع كود الاتصال بالخادم)
        setTimeout(() => {
            hideLoading();
            
            // عرض رسالة نجاح
            showAlert('تم إرسال رسالتك بنجاح! سأرد عليك في أقرب وقت.', 'success');
            
            // إعادة تعيين النموذج
            contactForm.reset();
            
            // إضافة الرسالة إلى سجل المحادثات (وهمي)
            addToChatHistory(formData);
            
            // إذا اختار واتساب، نفتح رابط واتساب
            if (formData.contactMethod === 'whatsapp') {
                setTimeout(() => {
                    const message = `مرحباً، اسمي ${formData.name}\n\n${formData.message}`;
                    const whatsappUrl = `https://wa.me/201112385864?text=${encodeURIComponent(message)}`;
                    window.open(whatsappUrl, '_blank');
                }, 1000);
            }
            
            // إذا اختار تليجرام، نفتح رابط تليجرام
            if (formData.contactMethod === 'telegram') {
                setTimeout(() => {
                    const message = `مرحباً، اسمي ${formData.name}\n\n${formData.message}`;
                    const telegramUrl = `https://t.me/01112385864?text=${encodeURIComponent(message)}`;
                    window.open(telegramUrl, '_blank');
                }, 1000);
            }
        }, 2000);
    });
}

// 4. التحقق من صحة النموذج
function validateForm(data) {
    // التحقق من الاسم
    if (!data.name || data.name.length < 3) {
        showAlert('الرجاء إدخال اسم صحيح (3 أحرف على الأقل)', 'error');
        return false;
    }
    
    // التحقق من البريد الإلكتروني
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
        showAlert('الرجاء إدخال بريد إلكتروني صحيح', 'error');
        return false;
    }
    
    // التحقق من الموضوع
    if (!data.subject) {
        showAlert('الرجاء اختيار موضوع الرسالة', 'error');
        return false;
    }
    
    // التحقق من الرسالة
    if (!data.message || data.message.length < 10) {
        showAlert('الرجاء كتابة رسالة ذات معنى (10 أحرف على الأقل)', 'error');
        return false;
    }
    
    return true;
}

// 5. عرض رسائل التنبيه
function showAlert(message, type = 'info') {
    // إنصراف عنصر التنبيه إذا كان موجوداً
    const existingAlert = document.querySelector('.custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // إنشاء عنصر التنبيه
    const alertDiv = document.createElement('div');
    alertDiv.className = `custom-alert ${type}`;
    alertDiv.innerHTML = `
        <div class="alert-content">
            <span class="alert-icon">${getAlertIcon(type)}</span>
            <span class="alert-text">${message}</span>
            <button class="alert-close">&times;</button>
        </div>
    `;
    
    // إضافة التنبيه إلى الصفحة
    document.body.appendChild(alertDiv);
    
    // إضافة تأثير الظهور
    setTimeout(() => {
        alertDiv.style.opacity = '1';
        alertDiv.style.transform = 'translateY(0)';
    }, 10);
    
    // إضافة حدث الإغلاق
    const closeBtn = alertDiv.querySelector('.alert-close');
    closeBtn.addEventListener('click', () => {
        hideAlert(alertDiv);
    });
    
    // إزالة التنبيه تلقائياً بعد 5 ثوانٍ
    setTimeout(() => {
        hideAlert(alertDiv);
    }, 5000);
    
    // إضافة أنماط CSS للتنبيه
    addAlertStyles();
}

// 6. الحصول على أيقونة التنبيه المناسبة
function getAlertIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        info: 'ℹ️',
        warning: '⚠️'
    };
    return icons[type] || icons.info;
}

// 7. إخفاء التنبيه
function hideAlert(alertDiv) {
    if (!alertDiv) return;
    
    alertDiv.style.opacity = '0';
    alertDiv.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 300);
}

// 8. عرض رسالة التحميل
function showLoading(message = 'جاري التحميل...') {
    // إنشاء عنصر التحميل
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'custom-loading';
    loadingDiv.innerHTML = `
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text">${message}</div>
        </div>
    `;
    
    // إضافة التحميل إلى الصفحة
    document.body.appendChild(loadingDiv);
    
    // إضافة أنماط CSS للتحميل
    addLoadingStyles();
}

// 9. إخفاء التحميل
function hideLoading() {
    const loadingDiv = document.querySelector('.custom-loading');
    if (loadingDiv) {
        loadingDiv.remove();
    }
}

// 10. تأثيرات التمرير
function initScrollEffects() {
    let lastScrollTop = 0;
    const header = document.querySelector('header');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // إظهار/إخفاء الهيدر عند التمرير
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // التمرير لأسفل
            header.style.transform = 'translateY(-100%)';
        } else {
            // التمرير لأعلى
            header.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;
        
        // تأثير الظهور التدريجي للعناصر
        const elements = document.querySelectorAll('.card, .project-item, .hobby, .skill');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementTop < windowHeight - 100) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    });
}

// 11. تهيئة الوضع المظلم
function initDarkMode() {
    // التحقق من تفضيلات المستخدم
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    const darkModeToggle = document.createElement('button');
    
    darkModeToggle.className = 'dark-mode-toggle';
    darkModeToggle.innerHTML = '🌙';
    darkModeToggle.title = 'تبديل الوضع المظلم';
    
    // إضافة زر التبديل إلى الهيدر
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.appendChild(darkModeToggle);
    }
    
    // تبديل الوضع المظلم
    darkModeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        
        if (document.body.classList.contains('dark-mode')) {
            this.innerHTML = '☀️';
            this.title = 'الوضع الفاتح';
            localStorage.setItem('darkMode', 'enabled');
        } else {
            this.innerHTML = '🌙';
            this.title = 'الوضع المظلم';
            localStorage.setItem('darkMode', 'disabled');
        }
    });
    
    // التحقق من الإعدادات المحفوظة
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode === 'enabled' || (!savedMode && prefersDark.matches)) {
        document.body.classList.add('dark-mode');
        darkModeToggle.innerHTML = '☀️';
        darkModeToggle.title = 'الوضع الفاتح';
    }
}

// 12. تحريك شريط المهارات
function initSkillsAnimation() {
    const skills = document.querySelectorAll('.skill');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const skillLevel = entry.target.querySelector('.skill-level');
                const percent = entry.target.querySelector('.skill-percent').textContent;
                
                // تحريك شريط المهارة
                skillLevel.style.transition = 'width 1.5s ease-in-out';
                skillLevel.style.width = percent;
                
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    skills.forEach(skill => observer.observe(skill));
}

// 13. قائمة الجوال
function initMobileMenu() {
    const menuToggle = document.createElement('button');
    menuToggle.className = 'mobile-menu-toggle';
    menuToggle.innerHTML = '☰';
    
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelector('.nav-links');
    
    if (navbar && navLinks) {
        navbar.appendChild(menuToggle);
        
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('show');
            this.innerHTML = navLinks.classList.contains('show') ? '✕' : '☰';
        });
        
        // إغلاق القائمة عند النقر على رابط
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('show');
                menuToggle.innerHTML = '☰';
            });
        });
    }
}

// 14. رسالة ترحيبية
function showWelcomeMessage() {
    // التحقق إذا كان المستخدم زائراً جديداً
    if (!localStorage.getItem('visited')) {
        setTimeout(() => {
            showAlert('مرحباً بك في موقعي! 😊 استمتع بتجربتك', 'info');
            localStorage.setItem('visited', 'true');
        }, 1000);
    }
}

// 15. إضافة محادثة للسجل (وهمي)
function addToChatHistory(formData) {
    console.log('📝 تم حفظ الرسالة في السجل:', formData);
    
    // هنا يمكنك إضافة كود لحفظ الرسائل في localStorage
    const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
    chatHistory.push({
        ...formData,
        timestamp: new Date().toISOString()
    });
    
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
}

// 16. إضافة أنماط CSS للتنبيهات
function addAlertStyles() {
    if (document.querySelector('#alert-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'alert-styles';
    style.textContent = `
        .custom-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            left: 20px;
            max-width: 400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            z-index: 9999;
            opacity: 0;
            transform: translateY(-20px);
            transition: all 0.3s ease;
        }
        
        .dark-mode .custom-alert {
            background: #2d2d2d;
            color: white;
        }
        
        .alert-content {
            display: flex;
            align-items: center;
            padding: 15px;
            gap: 10px;
        }
        
        .alert-icon {
            font-size: 20px;
        }
        
        .alert-text {
            flex: 1;
        }
        
        .alert-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .alert-close:hover {
            color: #ff6b6b;
        }
        
        .custom-alert.success {
            border-right: 5px solid #25D366;
        }
        
        .custom-alert.error {
            border-right: 5px solid #ff6b6b;
        }
        
        .custom-alert.info {
            border-right: 5px solid #1e3c72;
        }
    `;
    
    document.head.appendChild(style);
}

// 17. إضافة أنماط CSS للتحميل
function addLoadingStyles() {
    if (document.querySelector('#loading-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'loading-styles';
    style.textContent = `
        .custom-loading {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 99999;
        }
        
        .loading-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #1e3c72;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        .loading-text {
            color: #333;
            font-size: 18px;
            font-weight: bold;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    
    document.head.appendChild(style);
}

// 18. تحسينات للجوال
function addMobileStyles() {
    const style = document.createElement('style');
    style.textContent = `
        @media (max-width: 768px) {
            .mobile-menu-toggle {
                display: block;
                background: none;
                border: none;
                color: white;
                font-size: 24px;
                cursor: pointer;
                padding: 5px;
            }
            
            .nav-links {
                display: none;
                width: 100%;
                text-align: center;
            }
            
            .nav-links.show {
                display: flex;
                flex-direction: column;
                margin-top: 1rem;
            }
        }
    `;
    
    document.head.appendChild(style);
}

// 19. تهيئة أنماط الجوال
addMobileStyles();

// 20. تحديث التاريخ تلقائياً في الفوتر
function updateYear() {
    const yearElement = document.querySelector('footer p');
    if (yearElement && yearElement.textContent.includes('2023')) {
        const currentYear = new Date().getFullYear();
        yearElement.textContent = yearElement.textContent.replace('2023', currentYear);
    }
}

// تحديث السنة عند التحميل
updateYear();

// 21. إضافة تأثيرات للأزرار
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn, .submit-btn, .social-btn');
    
    buttons.forEach(button => {
        button.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        button.addEventListener('mouseup', function() {
            this.style.transform = '';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
});

// 22. تسجيل الأحداث للتحليلات (وهمي)
function trackEvent(eventName, data = {}) {
    console.log(`📊 حدث: ${eventName}`, data);
    
    // هنا يمكنك إضافة كود Google Analytics أو أي أداة تحليلات
    // مثال: gtag('event', eventName, data);
}

// 23. تتبع نقرات الروابط
document.addEventListener('click', function(e) {
    if (e.target.tagName === 'A' || e.target.closest('a')) {
        const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
        const href = link.getAttribute('href');
        
        if (href && (href.includes('whatsapp') || href.includes('telegram'))) {
            trackEvent('social_click', { platform: href.includes('whatsapp') ? 'whatsapp' : 'telegram' });
        }
    }
});

// 24. عرض عدد الزوار (وهمي)
function showVisitorCount() {
    let count = localStorage.getItem('visitorCount') || 0;
    count = parseInt(count) + 1;
    localStorage.setItem('visitorCount', count);
    
    // يمكنك عرض العدد في مكان ما في الصفحة
    console.log(`👥 عدد الزيارات: ${count}`);
}

// 25. تهيئة جميع الميزات عند التحميل
showVisitorCount();

// رسالة في الكونسول للمطورين
console.log(`
🚀 موقع ويب يعمل بكفاءة!
📞 للتواصل: 01112385864
📧 البريد: example@email.com
👨‍💻 المطور: مبتدئ متحمس
`);